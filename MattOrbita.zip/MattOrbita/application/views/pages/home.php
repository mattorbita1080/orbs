<h2><?= $title ?></h2>
<p>This is my home</p>